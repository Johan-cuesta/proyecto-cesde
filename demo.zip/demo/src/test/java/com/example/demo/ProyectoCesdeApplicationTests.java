package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCesdeApplicationTests {

	@Test
	void contextLoads() {
	}

}

@Entity
public class Curso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nombre;
    private String descripcion;
    private int duracionSemanas;
    private BigDecimal precio;
    private LocalDateTime fechaInicio;
    
    @ManyToOne
    @JoinColumn(name = "docente_id")
    private Docente docente;
    
    // getters y setters
}

@Entity
public class Docente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nombre;
    private String documento;
    private String correo;
    
    // getters y setters
}

public interface CursoRepository extends JpaRepository<Curso, Long> {
}

public interface DocenteRepository extends JpaRepository<Docente, Long> {
}

@Service
public class CursoService {
    @Autowired
    private CursoRepository cursoRepository;
    
    public List<Curso> obtenerTodos() {
        return cursoRepository.findAll();
    }
    
    public Curso guardar(Curso curso) {
        return cursoRepository.save(curso);
    }
    
    public void eliminar(Long id) {
        cursoRepository.deleteById(id);
    }
    
    // otros métodos según necesidad
}

@Service
public class DocenteService {
    @Autowired
    private DocenteRepository docenteRepository;
    
    public List<Docente> obtenerTodos() {
        return docenteRepository.findAll();
    }
    
    public Docente guardar(Docente docente) {
        return docenteRepository.save(docente);
    }
    
    public void eliminar(Long id) {
        docenteRepository.deleteById(id);
    }
    
    // otros métodos según necesidad
}

@Controller
@RequestMapping("/cursos")
public class CursoController {
    @Autowired
    private CursoService cursoService;
    
    @GetMapping
    public String listarCursos(Model model) {
        List<Curso> cursos = cursoService.obtenerTodos();
        model.addAttribute("cursos", cursos);
        return "cursos/lista"; // vista Thymeleaf
    }
    
    // otros métodos para agregar, editar y eliminar cursos
}

@Controller
@RequestMapping("/docentes")
public class DocenteController {
    @Autowired
    private DocenteService docenteService;
    
    @GetMapping
    public String listarDocentes(Model model) {
        List<Docente> docentes = docenteService.obtenerTodos();
        model.addAttribute("docentes", docentes);
        return "docentes/lista"; // vista Thymeleaf
    }
    
    // otros métodos para agregar, editar y eliminar docentes
}
